***README***
Run the following command dependant on your operating system in the \ByteCode folder.

Windows OS:
java -cp junit-4.12.jar;hamcrest-core-1.3.jar;. org.junit.runner.JUnitCore TestSuite

Mac & Linux OS:
to compile:
javac -cp junit-4.12.jar: TestSuite.java
to run:
java -cp junit-4.12.jar:hamcrest-core-1.3.jar:. org.junit.runner.JUnitCore TestSuite